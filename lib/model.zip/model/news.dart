class News {
  final String judul;
  final String Kategori;
  final String deskripsi;

  News(this.judul, this.Kategori, this.deskripsi);
}